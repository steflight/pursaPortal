   </div>
   </div>
   </div>
   </main>
   <footer class="app-footer">
        <a href="http://pursa.co">Pursa</a> © 2017 .
        <span class="float-right">Powered by <a href="http://globexcam.com">GlobexCam</a>
        </span>
    </footer>

    <!-- Bootstrap and necessary plugins -->
    <script src="node_modules/jquery/dist/jquery.min.js"></script>
    <script src="node_modules/popper.js/dist/umd/popper.min.js"></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="node_modules/pace-progress/pace.min.js"></script>


    <!-- Plugins and scripts required by all views -->
    <script src="node_modules/chart.js/dist/Chart.min.js"></script>


    <!-- GenesisUI main scripts -->

    <script src="js/app.js"></script>





    <!-- Plugins and scripts required by this views -->

    <!-- Custom scripts required by this view -->
    <script src="js/views/main.js"></script>
	
	</body>

</html>